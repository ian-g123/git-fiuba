git daemon --verbose --export-all --reuseaddr --enable=receive-pack --informative-errors --base-path=. .
